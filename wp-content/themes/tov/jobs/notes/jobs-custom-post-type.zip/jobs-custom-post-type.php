<?php
/**
 * Plugin Name: Jobs Custom Post Type
 * Description: Adds a custom Jobs post type with Category, Job Type, and Location fields
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class JobsCustomPostType {
    
    public function __construct() {
        add_action('init', array($this, 'create_jobs_post_type'));
        add_action('add_meta_boxes', array($this, 'add_jobs_meta_boxes'));
        add_action('save_post', array($this, 'save_jobs_meta_fields'));
        add_filter('manage_jobs_posts_columns', array($this, 'add_jobs_columns'));
        add_action('manage_jobs_posts_custom_column', array($this, 'populate_jobs_columns'), 10, 2);
    }
    
    /**
     * Create the Jobs custom post type
     */
    public function create_jobs_post_type() {
        $labels = array(
            'name'                  => 'Jobs',
            'singular_name'         => 'Job',
            'menu_name'             => 'Jobs',
            'name_admin_bar'        => 'Job',
            'archives'              => 'Job Archives',
            'attributes'            => 'Job Attributes',
            'parent_item_colon'     => 'Parent Job:',
            'all_items'             => 'All Jobs',
            'add_new_item'          => 'Add New Job',
            'add_new'               => 'Add New',
            'new_item'              => 'New Job',
            'edit_item'             => 'Edit Job',
            'update_item'           => 'Update Job',
            'view_item'             => 'View Job',
            'view_items'            => 'View Jobs',
            'search_items'          => 'Search Jobs',
            'not_found'             => 'Not found',
            'not_found_in_trash'    => 'Not found in Trash',
            'featured_image'        => 'Featured Image',
            'set_featured_image'    => 'Set featured image',
            'remove_featured_image' => 'Remove featured image',
            'use_featured_image'    => 'Use as featured image',
            'insert_into_item'      => 'Insert into job',
            'uploaded_to_this_item' => 'Uploaded to this job',
            'items_list'            => 'Jobs list',
            'items_list_navigation' => 'Jobs list navigation',
            'filter_items_list'     => 'Filter jobs list',
        );
        
        $args = array(
            'label'                 => 'Job',
            'description'           => 'Job listings',
            'labels'                => $labels,
            'supports'              => array('title', 'editor', 'thumbnail', 'excerpt'),
            'taxonomies'            => array(),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-businessman',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => true,
            'has_archive'           => true,
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'capability_type'       => 'post',
            'show_in_rest'          => true, // Enable Gutenberg support
        );
        
        register_post_type('jobs', $args);
    }
    
    /**
     * Add meta boxes for job fields
     */
    public function add_jobs_meta_boxes() {
        add_meta_box(
            'jobs_details',
            'Job Details',
            array($this, 'jobs_meta_box_callback'),
            'jobs',
            'normal',
            'high'
        );
    }
    
    /**
     * Meta box callback function
     */
    public function jobs_meta_box_callback($post) {
        // Add nonce for security
        wp_nonce_field('jobs_meta_box', 'jobs_meta_box_nonce');
        
        // Get current values
        $category = get_post_meta($post->ID, '_job_category', true);
        $job_type = get_post_meta($post->ID, '_job_type', true);
        $location = get_post_meta($post->ID, '_job_location', true);
        $salary = get_post_meta($post->ID, '_job_salary', true);
        $company = get_post_meta($post->ID, '_job_company', true);
        $application_email = get_post_meta($post->ID, '_job_application_email', true);
        $application_url = get_post_meta($post->ID, '_job_application_url', true);
        ?>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="job_category">Category</label>
                </th>
                <td>
                    <select name="job_category" id="job_category" style="width: 100%;">
                        <option value="">Select Category</option>
                        <option value="technology" <?php selected($category, 'technology'); ?>>Technology</option>
                        <option value="marketing" <?php selected($category, 'marketing'); ?>>Marketing</option>
                        <option value="sales" <?php selected($category, 'sales'); ?>>Sales</option>
                        <option value="finance" <?php selected($category, 'finance'); ?>>Finance</option>
                        <option value="hr" <?php selected($category, 'hr'); ?>>Human Resources</option>
                        <option value="operations" <?php selected($category, 'operations'); ?>>Operations</option>
                        <option value="design" <?php selected($category, 'design'); ?>>Design</option>
                        <option value="customer-service" <?php selected($category, 'customer-service'); ?>>Customer Service</option>
                        <option value="other" <?php selected($category, 'other'); ?>>Other</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_type">Job Type</label>
                </th>
                <td>
                    <select name="job_type" id="job_type" style="width: 100%;">
                        <option value="">Select Job Type</option>
                        <option value="full-time" <?php selected($job_type, 'full-time'); ?>>Full Time</option>
                        <option value="part-time" <?php selected($job_type, 'part-time'); ?>>Part Time</option>
                        <option value="contract" <?php selected($job_type, 'contract'); ?>>Contract</option>
                        <option value="freelance" <?php selected($job_type, 'freelance'); ?>>Freelance</option>
                        <option value="internship" <?php selected($job_type, 'internship'); ?>>Internship</option>
                        <option value="temporary" <?php selected($job_type, 'temporary'); ?>>Temporary</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_location">Location</label>
                </th>
                <td>
                    <input type="text" name="job_location" id="job_location" value="<?php echo esc_attr($location); ?>" style="width: 100%;" placeholder="e.g., New York, NY or Remote" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_salary">Salary</label>
                </th>
                <td>
                    <input type="text" name="job_salary" id="job_salary" value="<?php echo esc_attr($salary); ?>" style="width: 100%;" placeholder="e.g., $50,000 - $70,000" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_company">Company</label>
                </th>
                <td>
                    <input type="text" name="job_company" id="job_company" value="<?php echo esc_attr($company); ?>" style="width: 100%;" placeholder="Company name" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_application_email">Application Email</label>
                </th>
                <td>
                    <input type="email" name="job_application_email" id="job_application_email" value="<?php echo esc_attr($application_email); ?>" style="width: 100%;" placeholder="jobs@company.com" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="job_application_url">Application URL</label>
                </th>
                <td>
                    <input type="url" name="job_application_url" id="job_application_url" value="<?php echo esc_attr($application_url); ?>" style="width: 100%;" placeholder="https://company.com/apply" />
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Save meta fields
     */
    public function save_jobs_meta_fields($post_id) {
        // Check if nonce is valid
        if (!isset($_POST['jobs_meta_box_nonce']) || !wp_verify_nonce($_POST['jobs_meta_box_nonce'], 'jobs_meta_box')) {
            return;
        }
        
        // Check if user has permission to edit the post
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Save meta fields
        $fields = array(
            '_job_category',
            '_job_type',
            '_job_location',
            '_job_salary',
            '_job_company',
            '_job_application_email',
            '_job_application_url'
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[str_replace('_job_', 'job_', $field)])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[str_replace('_job_', 'job_', $field)]));
            }
        }
    }
    
    /**
     * Add custom columns to jobs list
     */
    public function add_jobs_columns($columns) {
        $new_columns = array();
        $new_columns['cb'] = $columns['cb'];
        $new_columns['title'] = $columns['title'];
        $new_columns['job_category'] = 'Category';
        $new_columns['job_type'] = 'Job Type';
        $new_columns['job_location'] = 'Location';
        $new_columns['job_company'] = 'Company';
        $new_columns['date'] = $columns['date'];
        
        return $new_columns;
    }
    
    /**
     * Populate custom columns
     */
    public function populate_jobs_columns($column, $post_id) {
        switch ($column) {
            case 'job_category':
                $category = get_post_meta($post_id, '_job_category', true);
                echo ucfirst(str_replace('-', ' ', $category));
                break;
            case 'job_type':
                $job_type = get_post_meta($post_id, '_job_type', true);
                echo ucfirst(str_replace('-', ' ', $job_type));
                break;
            case 'job_location':
                echo get_post_meta($post_id, '_job_location', true);
                break;
            case 'job_company':
                echo get_post_meta($post_id, '_job_company', true);
                break;
        }
    }
}

// Initialize the plugin
new JobsCustomPostType();

// Add some CSS for better styling
add_action('admin_head', function() {
    ?>
    <style>
        .jobs-meta-box .form-table th {
            width: 150px;
        }
        .jobs-meta-box .form-table td {
            padding: 10px;
        }
        .jobs-meta-box select,
        .jobs-meta-box input[type="text"],
        .jobs-meta-box input[type="email"],
        .jobs-meta-box input[type="url"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
    <?php
});
?>
